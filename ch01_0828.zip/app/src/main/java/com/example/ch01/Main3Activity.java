package com.example.ch01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {
    Button button11, button22;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        button11 = (Button) findViewById(R.id.button11);
        button22 = (Button) findViewById(R.id.button22);
        text = (TextView) findViewById(R.id.editText);

        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), text.getText(), Toast.LENGTH_SHORT).show();

            }
        });


    }
}
